﻿namespace Domains
{
    public enum DutyCategory
    {
        Work,
        Personal,
        Educational,
        Financial,
        Other
    }
}