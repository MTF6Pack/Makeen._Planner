﻿namespace Domains
{
    public enum PriorityCategory
    {
        High = 1,
        Moderate = 2,
        low = 3
    }
}
