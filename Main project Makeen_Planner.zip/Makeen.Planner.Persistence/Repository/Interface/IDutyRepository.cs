﻿using Domains;
using Repository.Base;

namespace Repository.Interface
{
    public interface IDutyRepository : IRepository<Duty>
    {
    }
}
