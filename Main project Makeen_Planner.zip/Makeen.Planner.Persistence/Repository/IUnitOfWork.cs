﻿namespace Repository
{
    public interface IUnitOfWork
    {
        void SaveChanges();
    }
}
