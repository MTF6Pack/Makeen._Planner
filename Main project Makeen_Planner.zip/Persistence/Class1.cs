﻿namespace Persistence
{
    public class Class1
    {

    }
}
